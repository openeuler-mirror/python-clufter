# -*- coding: UTF-8 -*-
# Copyright 2017 Red Hat, Inc.
# Part of clufter project
# Licensed under GPLv2+ (a copy included | http://gnu.org/licenses/gpl-2.0.txt)
__author__ = "Jan Pokorný <jpokorny @at@ Red Hat .dot. com>"

cib2pcscmd = '''\
    <clufter:descent-mix at="acl_role"/>
    <clufter:descent-mix at="acl_target"/>
    <clufter:descent-mix at="acl_group"/>
'''
