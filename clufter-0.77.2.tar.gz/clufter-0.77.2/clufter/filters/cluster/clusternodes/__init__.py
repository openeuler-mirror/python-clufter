# -*- coding: UTF-8 -*-
# Copyright 2015 Red Hat, Inc.
# Part of clufter project
# Licensed under GPLv2+ (a copy included | http://gnu.org/licenses/gpl-2.0.txt)

ccs2needlexml = '''\
    <nodelist>
        <clufter:descent at="clusternode"/>
    </nodelist>
'''

ccsflat2cibprelude = '''\
    <nodes>
        <clufter:descent at="clusternode"/>
    </nodes>
'''
